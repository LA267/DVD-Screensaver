# DVD Screensaver Application - Design Guidelines

## Design Approach
**Material Design System** - Selected for its clean component patterns, clear hierarchy, and excellent form controls that match the utility-focused nature of this customization tool. Material's elevation system and structured layouts provide the minimalist aesthetic while maintaining functional clarity.

## Typography System
**Font Stack**: Inter or Roboto via Google Fonts CDN
- **Headers (H1)**: 2.25rem (36px), medium weight - App title
- **Section Labels**: 0.875rem (14px), medium weight, uppercase, letter-spacing 0.05em
- **Control Labels**: 1rem (16px), regular weight
- **Values/Indicators**: 0.875rem (14px), medium weight
- **Helper Text**: 0.75rem (12px), regular weight

## Layout System
**Spacing Units**: Tailwind classes using 2, 4, 6, 8, 12, 16, 20 units for consistency

**App Structure**:
- Full viewport height application (h-screen)
- Two-column layout on desktop (lg:grid-cols-[350px_1fr])
- Single column (stacked) on mobile
- Control sidebar: 350px fixed width on desktop, full width on mobile
- Screensaver canvas: Fills remaining space

## Component Library

### Control Sidebar
**Container**: Fixed width sidebar with padding p-6, subtle border-r
- Sticky positioning on desktop for controls visibility
- Scrollable if content exceeds viewport
- Background surface with subtle elevation

**Control Sections**: Each control group with mb-8 spacing
- Section label (mb-3)
- Control element
- Helper text below (mt-2) if needed

**Logo Size Control**:
- Range slider (full width)
- Value display showing current size (e.g., "120px")
- Min/max labels at slider ends

**Background Color Control**:
- Color picker input (native HTML5 color input)
- Current color preview square (48px × 48px) with rounded corners
- Hex value display

**Background Image Control**:
- File upload button (styled as primary action)
- Image preview thumbnail (120px × 120px) when selected
- "Clear Image" secondary button when image active
- Drag-and-drop zone styling for enhanced UX

**Action Buttons**:
- "Reset to Default" button at bottom (secondary style)
- "Pause/Play" toggle for screensaver animation (primary style)

### Screensaver Canvas
**Main Display Area**: 
- Fills available space (flex-1)
- Displays bouncing DVD logo
- Background transitions smoothly when color/image changes
- Logo maintains aspect ratio, scales based on size control
- Smooth animation using CSS transforms

**DVD Logo**:
- Classic DVD logo or custom brand logo
- Changes color when hitting edges (classic screensaver behavior)
- Shadow/glow effect for visibility on various backgrounds

## Spacing & Layout Details

**Sidebar Internal Spacing**:
- Section groups: mb-8
- Label to control: mb-3
- Between related controls: mb-4
- Padding: p-6 overall

**Canvas Area**:
- No padding (logo bounces edge-to-edge)
- Center initial logo position
- Smooth animation at 60fps

**Responsive Breakpoints**:
- Mobile (<1024px): Stack sidebar above canvas, sidebar becomes collapsible drawer
- Desktop (≥1024px): Side-by-side layout with fixed sidebar width

## Images
**No Hero Image** - This is a functional application where the screensaver canvas itself is the primary visual element.

**Background Image Placeholder**: When no custom image selected, show subtle grid pattern or solid surface to indicate the customizable area.

## Interactive States
- Focus states on all inputs with subtle outline
- Slider thumb has hover scale effect
- File upload button shows hover elevation
- All transitions smooth at 200-300ms