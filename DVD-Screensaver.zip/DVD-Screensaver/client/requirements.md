## Packages
framer-motion | Smooth UI transitions for the control panel
react-use | Useful hooks for window size and measuring

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["'Space Mono'", "monospace"],
  sans: ["'Space Grotesk'", "sans-serif"],
}
