import { useRef, useState, useEffect } from "react";
import { useSettings } from "@/hooks/use-settings";
import { useScreensaver } from "@/hooks/use-screensaver";
import { DvdLogo } from "@/components/DvdLogo";
import { SettingsPanel } from "@/components/SettingsPanel";
import { Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);
  
  // Dimensions state to feed into hook
  const [dimensions, setDimensions] = useState({ width: 192, height: 96 }); // approx default
  
  const { data: settings, isLoading, isError } = useSettings();

  // Update dimensions when logo renders
  useEffect(() => {
    const measure = () => {
      if (logoRef.current) {
        const rect = logoRef.current.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          // Subtract scaling artifacts if necessary, but here we want actual render size
          setDimensions({
            width: rect.width,
            height: rect.height,
          });
        }
      }
    };

    measure();
    // Re-measure after a frame to be sure
    const frame = requestAnimationFrame(measure);
    return () => cancelAnimationFrame(frame);
  }, [settings?.logoText, settings?.logoUrl, settings?.logoScale]);

  const { position, color: randomColor, fps } = useScreensaver(
    containerRef, 
    dimensions.width, 
    dimensions.height, 
    settings?.speed ?? 5
  );

  const displayColor = settings?.useRandomColor ? randomColor : (settings?.backgroundColor || "#FFFFFF");

  if (isLoading) {
    return (
      <div className="h-screen w-full bg-black flex items-center justify-center text-white">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="font-mono text-sm tracking-widest text-muted-foreground animate-pulse">LOADING SYSTEM...</p>
        </div>
      </div>
    );
  }

  if (isError || !settings) {
    return (
      <div className="h-screen w-full bg-black flex items-center justify-center text-white p-8">
        <div className="max-w-md text-center space-y-4 border border-red-500/20 bg-red-500/10 p-8 rounded-2xl backdrop-blur-sm">
          <h1 className="text-xl font-bold font-sans text-red-500">SYSTEM ERROR</h1>
          <p className="text-muted-foreground">Failed to load screensaver configuration.</p>
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded font-mono text-sm uppercase transition-colors"
          >
            Reboot System
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="relative w-screen h-screen overflow-hidden text-white crt"
      style={{
        backgroundColor: settings.backgroundColor,
        backgroundImage: settings.backgroundImageUrl ? `url(${settings.backgroundImageUrl})` : undefined,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Settings Control */}
      <SettingsPanel settings={settings} />

      {/* Main Screensaver Container */}
      <div 
        ref={containerRef} 
        className="absolute inset-0 z-10"
      >
        <div
          ref={logoRef}
          style={{
            transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
            willChange: "transform",
          }}
          className="absolute top-0 left-0"
        >
          <DvdLogo 
            text={settings.logoText} 
            logoUrl={settings.logoUrl}
            color={displayColor}
            scale={settings.logoScale}
          />
        </div>
      </div>

      {/* FPS Counter */}
      <AnimatePresence>
        {settings.showFps && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute bottom-4 left-4 z-20 font-mono text-xs text-green-500 bg-black/50 px-2 py-1 rounded border border-green-500/20 backdrop-blur-sm"
          >
            FPS: {fps}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
