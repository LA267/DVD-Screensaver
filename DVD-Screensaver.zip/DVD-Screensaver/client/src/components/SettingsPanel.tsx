import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Settings } from "@shared/schema";
import { useUpdateSettings } from "@/hooks/use-settings";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Settings2, Loader2, Upload } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Client-side validation schema (matching backend omit id)
const formSchema = z.object({
  logoText: z.string().min(1, "Text is required").max(10, "Max 10 chars"),
  logoUrl: z.string().optional().or(z.literal("")),
  speed: z.coerce.number().min(1).max(20),
  showFps: z.boolean(),
  logoScale: z.coerce.number().min(20).max(300),
  backgroundColor: z.string(),
  backgroundImageUrl: z.string().optional().or(z.literal("")),
  useRandomColor: z.boolean(),
  language: z.enum(["en", "de"]),
});

const translations = {
  en: {
    title: "Config",
    description: "ADJUST SCREENSAVER PARAMETERS",
    displayText: "Display Text",
    customLogo: "Custom Logo",
    logoSize: "Logo Size",
    backgroundColor: "Background Color",
    backgroundImage: "Background Image",
    movementSpeed: "Movement Speed",
    showFps: "Show FPS Counter",
    randomColor: "Random Color Switching",
    language: "Language",
    apply: "APPLY CHANGES",
    saving: "SAVING...",
    uploadSuccess: (field: string) => `${field} uploaded successfully`,
  },
  de: {
    title: "Konfiguration",
    description: "BILDSCHIRMSCHONER-PARAMETER ANPASSEN",
    displayText: "Anzeigetext",
    customLogo: "Benutzerdefiniertes Logo",
    logoSize: "Logogröße",
    backgroundColor: "Hintergrundfarbe",
    backgroundImage: "Hintergrundbild",
    movementSpeed: "Geschwindigkeit",
    showFps: "FPS-Anzeige",
    randomColor: "Zufälliger Farbwechsel",
    language: "Sprache",
    apply: "ÄNDERUNGEN ÜBERNEHMEN",
    saving: "SPEICHERN...",
    uploadSuccess: (field: string) => `${field === "Logo" ? "Logo" : "Hintergrund"} erfolgreich hochgeladen`,
  },
};

type FormData = z.infer<typeof formSchema>;

interface SettingsPanelProps {
  settings: Settings;
}

export function SettingsPanel({ settings }: SettingsPanelProps) {
  const [open, setOpen] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const [isUploadingBg, setIsUploadingBg] = useState(false);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);
  const updateSettings = useUpdateSettings();
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      logoText: settings.logoText,
      logoUrl: settings.logoUrl || "",
      speed: settings.speed,
      showFps: settings.showFps,
      logoScale: settings.logoScale ?? 100,
      backgroundColor: settings.backgroundColor ?? "#000000",
      backgroundImageUrl: settings.backgroundImageUrl || "",
      useRandomColor: settings.useRandomColor ?? true,
      language: (settings as any).language || "en",
    },
  });

  const currentLang = form.watch("language") as keyof typeof translations;
  const t = translations[currentLang];

  // Reset form when settings change from outside (e.g. initial load)
  useEffect(() => {
    form.reset({
      logoText: settings.logoText,
      logoUrl: settings.logoUrl || "",
      speed: settings.speed,
      showFps: settings.showFps,
      logoScale: settings.logoScale ?? 100,
      backgroundColor: settings.backgroundColor ?? "#000000",
      backgroundImageUrl: settings.backgroundImageUrl || "",
      useRandomColor: settings.useRandomColor ?? true,
      language: (settings as any).language || "en",
    });
  }, [settings, form]);

  const onFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: "logoUrl" | "backgroundImageUrl") => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    if (field === "logoUrl") setIsUploadingLogo(true);
    else setIsUploadingBg(true);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) throw new Error("Upload failed");

      const data = await res.json();
      form.setValue(field, data.url);
      toast({
        title: "Success",
        description: `${field === "logoUrl" ? "Logo" : "Background"} uploaded successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload image",
        variant: "destructive",
      });
    } finally {
      if (field === "logoUrl") setIsUploadingLogo(false);
      else setIsUploadingBg(false);
    }
  };

  const onSubmit = (data: FormData) => {
    updateSettings.mutate(data, {
      onSuccess: () => {
        setOpen(false);
      },
    });
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="fixed top-4 right-4 z-50 rounded-full w-12 h-12 glass-panel hover:bg-white/10 text-white border-white/20 hover:scale-105 transition-transform"
        >
          <Settings2 className="w-5 h-5" />
          <span className="sr-only">Settings</span>
        </Button>
      </SheetTrigger>
      <SheetContent className="glass-panel border-l border-white/10 text-white w-full sm:max-w-md overflow-y-auto">
        <SheetHeader className="mb-8">
          <SheetTitle className="text-2xl font-sans font-bold text-white">{t.title}</SheetTitle>
          <SheetDescription className="text-gray-400 font-mono text-xs">
            {t.description}
          </SheetDescription>
        </SheetHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {/* Logo Text */}
          <div className="space-y-4">
            <Label htmlFor="logoText" className="text-sm font-mono uppercase tracking-wider text-gray-400">
              {t.displayText}
            </Label>
            <Input
              id="logoText"
              {...form.register("logoText")}
              className="bg-white/5 border-white/10 text-white focus:border-primary font-sans text-lg h-12"
              placeholder="DVD"
              maxLength={10}
            />
            {form.formState.errors.logoText && (
              <p className="text-red-400 text-xs font-mono">{form.formState.errors.logoText.message}</p>
            )}
          </div>

          {/* Logo URL / Upload */}
          <div className="space-y-4">
            <Label htmlFor="logoUrl" className="text-sm font-mono uppercase tracking-wider text-gray-400">
              {t.customLogo}
            </Label>
            <div className="flex gap-2">
              <Input
                id="logoUrl"
                {...form.register("logoUrl")}
                className="bg-white/5 border-white/10 text-white focus:border-primary font-sans text-lg h-12"
                placeholder="URL or Upload..."
              />
              <input
                type="file"
                ref={logoInputRef}
                className="hidden"
                accept="image/*"
                onChange={(e) => onFileUpload(e, "logoUrl")}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                disabled={isUploadingLogo}
                onClick={() => logoInputRef.current?.click()}
                className="h-12 w-12 shrink-0 glass-panel border-white/10 hover:bg-white/10 text-white"
              >
                {isUploadingLogo ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Upload className="w-5 h-5" />
                )}
              </Button>
            </div>
            {form.formState.errors.logoUrl && (
              <p className="text-red-400 text-xs font-mono">{form.formState.errors.logoUrl.message}</p>
            )}
            <p className="text-gray-500 text-[10px] font-mono leading-tight">
              PASTE A URL OR CLICK THE ICON TO UPLOAD
            </p>
          </div>

          {/* Logo Scale Slider */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label htmlFor="logoScale" className="text-sm font-mono uppercase tracking-wider text-gray-400">
                {t.logoSize}
              </Label>
              <span className="font-mono text-primary font-bold">{form.watch("logoScale")}%</span>
            </div>
            <Slider
              id="logoScale"
              min={20}
              max={300}
              step={10}
              value={[form.watch("logoScale")]}
              onValueChange={(vals) => form.setValue("logoScale", vals[0])}
              className="py-4"
            />
          </div>

          {/* Background Color Picker */}
          <div className="space-y-4">
            <Label htmlFor="backgroundColor" className="text-sm font-mono uppercase tracking-wider text-gray-400">
              {t.backgroundColor}
            </Label>
            <div className="flex gap-4 items-center">
              <input
                type="color"
                id="backgroundColor"
                value={form.watch("backgroundColor")}
                onChange={(e) => form.setValue("backgroundColor", e.target.value)}
                className="w-12 h-12 rounded-lg bg-transparent cursor-pointer border-none"
              />
              <Input
                value={form.watch("backgroundColor")}
                onChange={(e) => form.setValue("backgroundColor", e.target.value)}
                className="bg-white/5 border-white/10 text-white font-mono h-12"
              />
            </div>
          </div>

          {/* Background Image Upload */}
          <div className="space-y-4">
            <Label htmlFor="backgroundImageUrl" className="text-sm font-mono uppercase tracking-wider text-gray-400">
              {t.backgroundImage}
            </Label>
            <div className="flex gap-2">
              <Input
                id="backgroundImageUrl"
                {...form.register("backgroundImageUrl")}
                className="bg-white/5 border-white/10 text-white focus:border-primary font-sans text-lg h-12"
                placeholder="URL or Upload..."
              />
              <input
                type="file"
                ref={bgInputRef}
                className="hidden"
                accept="image/*"
                onChange={(e) => onFileUpload(e, "backgroundImageUrl")}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                disabled={isUploadingBg}
                onClick={() => bgInputRef.current?.click()}
                className="h-12 w-12 shrink-0 glass-panel border-white/10 hover:bg-white/10 text-white"
              >
                {isUploadingBg ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Upload className="w-5 h-5" />
                )}
              </Button>
            </div>
          </div>

          {/* Speed Slider */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label htmlFor="speed" className="text-sm font-mono uppercase tracking-wider text-gray-400">
                {t.movementSpeed}
              </Label>
              <span className="font-mono text-primary font-bold">{form.watch("speed")}x</span>
            </div>
            <Slider
              id="speed"
              min={1}
              max={20}
              step={1}
              value={[form.watch("speed")]}
              onValueChange={(vals) => form.setValue("speed", vals[0])}
              className="py-4"
            />
          </div>

          {/* FPS Toggle */}
          <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
            <Label htmlFor="showFps" className="text-sm font-mono uppercase tracking-wider text-gray-400">
              {t.showFps}
            </Label>
            <Switch
              id="showFps"
              checked={form.watch("showFps")}
              onCheckedChange={(checked) => form.setValue("showFps", checked)}
            />
          </div>

          {/* Random Color Toggle */}
          <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
            <Label htmlFor="useRandomColor" className="text-sm font-mono uppercase tracking-wider text-gray-400">
              {t.randomColor}
            </Label>
            <Switch
              id="useRandomColor"
              checked={form.watch("useRandomColor")}
              onCheckedChange={(checked) => form.setValue("useRandomColor", checked)}
            />
          </div>

          {/* Language Selector */}
          <div className="space-y-4">
            <Label className="text-sm font-mono uppercase tracking-wider text-gray-400">
              {t.language}
            </Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={form.watch("language") === "en" ? "default" : "outline"}
                className="flex-1"
                onClick={() => form.setValue("language", "en")}
              >
                English
              </Button>
              <Button
                type="button"
                variant={form.watch("language") === "de" ? "default" : "outline"}
                className="flex-1"
                onClick={() => form.setValue("language", "de")}
              >
                Deutsch
              </Button>
            </div>
          </div>

          <Button
            type="submit"
            disabled={updateSettings.isPending}
            className="w-full h-12 bg-primary hover:bg-primary/90 text-white font-bold tracking-wide font-sans text-lg rounded-xl shadow-lg shadow-primary/25"
          >
            {updateSettings.isPending ? (
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
            ) : null}
            {updateSettings.isPending ? t.saving : t.apply}
          </Button>
        </form>
      </SheetContent>
    </Sheet>
  );
}
