import { forwardRef } from "react";
import { cn } from "@/lib/utils";

interface DvdLogoProps {
  text?: string;
  logoUrl?: string | null;
  color: string;
  className?: string;
  scale?: number;
}

export const DvdLogo = forwardRef<HTMLDivElement, DvdLogoProps>(
  ({ text = "DVD", logoUrl, color, className, scale = 100 }, ref) => {
    const scaleFactor = scale / 100;
    return (
      <div
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center select-none",
          className
        )}
        style={{ color, transform: `scale(${scaleFactor})`, transformOrigin: "top left" }}
      >
        <div className="flex flex-col items-center">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Custom Logo"
              className="w-32 h-16 md:w-48 md:h-24 object-contain filter drop-shadow-[0_0_8px_currentColor]"
              style={{ filter: `drop-shadow(0 0 8px ${color}) brightness(1.2)` }}
              onError={(e) => {
                // Fallback if image fails to load
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
          ) : (
            <svg
              viewBox="0 0 120 60"
              className="w-32 h-16 md:w-48 md:h-24 filter drop-shadow-[0_0_8px_currentColor]"
              fill="currentColor"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Simple DVD-like Swoosh and Text */}
              <path d="M10,50 Q60,60 110,50 L110,55 Q60,65 10,55 Z" opacity="0.8" />
              <text
                x="60"
                y="45"
                textAnchor="middle"
                className="font-black tracking-widest uppercase"
                fontSize="40"
                fontFamily="var(--font-sans)"
                fontWeight="900"
              >
                {text}
              </text>
              <text
                x="60"
                y="56"
                textAnchor="middle"
                className="font-mono tracking-[0.2em] uppercase"
                fontSize="8"
                fontFamily="var(--font-mono)"
              >
                VIDEO
              </text>
            </svg>
          )}
        </div>
      </div>
    );
  }
);

DvdLogo.displayName = "DvdLogo";
