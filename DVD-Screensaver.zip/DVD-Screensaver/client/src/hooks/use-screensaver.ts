import { useState, useEffect, useRef, useCallback } from "react";

const COLORS = [
  "#FF0000", // Red
  "#00FF00", // Green
  "#0000FF", // Blue
  "#FFFF00", // Yellow
  "#00FFFF", // Cyan
  "#FF00FF", // Magenta
  "#FFA500", // Orange
  "#FFFFFF", // White
];

interface Position {
  x: number;
  y: number;
}

interface Velocity {
  dx: number;
  dy: number;
}

export function useScreensaver(
  containerRef: React.RefObject<HTMLDivElement>,
  logoWidth: number,
  logoHeight: number,
  speedMultiplier: number = 5
) {
  const [position, setPosition] = useState<Position>({ x: 100, y: 100 });
  const [color, setColor] = useState<string>(COLORS[0]);
  const [fps, setFps] = useState(0);
  
  // Use refs for values updated in the animation loop to avoid re-creating the loop
  const posRef = useRef<Position>({ x: 100, y: 100 });
  const velRef = useRef<Velocity>({ dx: 1, dy: 1 });
  const requestRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);
  const frameCountRef = useRef<number>(0);
  const lastFpsUpdateRef = useRef<number>(0);

  const animate = useCallback((time: number) => {
    if (!lastTimeRef.current) lastTimeRef.current = time;
    const deltaTime = time - lastTimeRef.current;
    lastTimeRef.current = time;

    // FPS Calculation
    frameCountRef.current++;
    if (time - lastFpsUpdateRef.current >= 1000) {
      setFps(Math.round((frameCountRef.current * 1000) / (time - lastFpsUpdateRef.current)));
      frameCountRef.current = 0;
      lastFpsUpdateRef.current = time;
    }

    if (!containerRef.current) {
      requestRef.current = requestAnimationFrame(animate);
      return;
    }

    const { clientWidth, clientHeight } = containerRef.current;
    
    // Calculate new position
    // Base speed is adjusted by deltaTime to be frame-rate independent roughly
    // But for a retro feel, simple linear movement per frame is often preferred.
    // We'll use a simple multiplier.
    const moveX = velRef.current.dx * (speedMultiplier * 0.5); 
    const moveY = velRef.current.dy * (speedMultiplier * 0.5);

    // Precise bounce detection
    let newX = posRef.current.x + moveX;
    let newY = posRef.current.y + moveY;
    let hit = false;

    // Left wall
    if (newX < 0) {
      newX = 0;
      velRef.current.dx = Math.abs(velRef.current.dx);
      hit = true;
    } 
    // Right wall
    else if (newX + logoWidth > clientWidth) {
      newX = clientWidth - logoWidth;
      velRef.current.dx = -Math.abs(velRef.current.dx);
      hit = true;
    }

    // Top wall
    if (newY < 0) {
      newY = 0;
      velRef.current.dy = Math.abs(velRef.current.dy);
      hit = true;
    } 
    // Bottom wall
    else if (newY + logoHeight > clientHeight) {
      newY = clientHeight - logoHeight;
      velRef.current.dy = -Math.abs(velRef.current.dy);
      hit = true;
    }

    if (hit) {
      // Pick a random new color different from the current one
      let newColor = color;
      do {
        newColor = COLORS[Math.floor(Math.random() * COLORS.length)];
      } while (newColor === color && COLORS.length > 1);
      setColor(newColor);
    }

    posRef.current = { x: newX, y: newY };
    setPosition(posRef.current);

    requestRef.current = requestAnimationFrame(animate);
  }, [containerRef, logoWidth, logoHeight, speedMultiplier, color]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [animate]);

  // Handle window resize to keep logo in bounds
  useEffect(() => {
    const handleResize = () => {
      if (!containerRef.current) return;
      const { clientWidth, clientHeight } = containerRef.current;
      
      let adjusted = false;
      let { x, y } = posRef.current;

      if (x + logoWidth > clientWidth) {
        x = Math.max(0, clientWidth - logoWidth);
        adjusted = true;
      }
      if (y + logoHeight > clientHeight) {
        y = Math.max(0, clientHeight - logoHeight);
        adjusted = true;
      }

      if (adjusted) {
        posRef.current = { x, y };
        setPosition({ x, y });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [containerRef, logoWidth, logoHeight]);

  return { position, color, fps };
}
