import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  speed: integer("speed").notNull().default(5),
  logoText: text("logo_text").notNull().default("DVD"),
  logoUrl: text("logo_url"),
  showFps: boolean("show_fps").notNull().default(false),
  logoScale: integer("logo_scale").notNull().default(100),
  backgroundColor: text("background_color").notNull().default("#000000"),
  backgroundImageUrl: text("background_image_url"),
  useRandomColor: boolean("use_random_color").notNull().default(true),
  language: text("language").notNull().default("en"),
});

export const insertSettingsSchema = createInsertSchema(settings).omit({ id: true });
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;
