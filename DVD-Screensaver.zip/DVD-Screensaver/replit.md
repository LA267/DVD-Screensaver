# DVD Screensaver Application

## Overview

A nostalgic DVD screensaver web application that displays a bouncing logo that changes color when hitting screen edges. Built as a full-stack TypeScript application with React frontend and Express backend, featuring customizable settings for speed, logo text, custom images, and FPS display.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with hot module replacement
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with CSS variables for theming
- **UI Components**: shadcn/ui component library (Radix UI primitives)
- **Animations**: Framer Motion for smooth transitions
- **Fonts**: Space Grotesk (sans) and Space Mono (mono)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **API Pattern**: REST endpoints defined in shared/routes.ts with Zod validation
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Build**: esbuild for production bundling

### Project Structure
```
├── client/           # React frontend application
│   └── src/
│       ├── components/  # UI components including shadcn/ui
│       ├── hooks/       # Custom React hooks
│       ├── pages/       # Route pages
│       └── lib/         # Utilities and query client
├── server/           # Express backend
│   ├── index.ts      # Server entry point
│   ├── routes.ts     # API route handlers
│   ├── storage.ts    # Database abstraction layer
│   └── db.ts         # Database connection
├── shared/           # Shared code between client/server
│   ├── schema.ts     # Drizzle database schema
│   └── routes.ts     # API route definitions with Zod schemas
└── migrations/       # Drizzle database migrations
```

### Key Design Patterns
- **Shared Types**: Schema and route definitions shared between frontend and backend
- **Storage Interface**: `IStorage` interface abstracts database operations for testability
- **Type-Safe API**: Zod schemas validate both request inputs and response outputs
- **Path Aliases**: `@/` for client code, `@shared/` for shared code

### Database Schema
Single `settings` table storing screensaver configuration:
- `id`: Serial primary key
- `speed`: Integer (1-20), animation speed multiplier
- `logoText`: Text, customizable logo text (default "DVD")
- `logoUrl`: Optional URL for custom logo image
- `showFps`: Boolean, toggle FPS counter display

## External Dependencies

### Database
- **PostgreSQL**: Primary database via `DATABASE_URL` environment variable
- **Drizzle ORM**: Schema management and query building
- **drizzle-kit**: Database migrations with `npm run db:push`

### Frontend Libraries
- **@tanstack/react-query**: Server state management and caching
- **framer-motion**: Animation library for UI transitions
- **react-hook-form**: Form state management with Zod resolver
- **wouter**: Client-side routing
- **lucide-react**: Icon library

### UI Framework
- **shadcn/ui**: Pre-built accessible components using Radix UI
- **Tailwind CSS**: Utility-first CSS framework
- **class-variance-authority**: Component variant management

### Development
- **Vite**: Development server with HMR
- **tsx**: TypeScript execution for development
- **esbuild**: Production build bundling